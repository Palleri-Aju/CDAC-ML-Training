"""Builds 06_customer_data_dirty.csv and Trainer_Data_Quality_Manifest.csv.

Every defect is injected deliberately into a known row/column, then every count in the
manifest is RE-DETECTED from the written CSV and checked against what was injected.
"""
import random, re, csv
from datetime import date, timedelta
import numpy as np
import pandas as pd

SEED = 2026
rng = np.random.default_rng(SEED)
random.seed(SEED)

N_BASE = 460
CITIES = ["Mumbai", "Delhi", "Bengaluru", "Chennai", "Hyderabad", "Pune", "Kolkata", "Ahmedabad"]
CITY_P = [0.20, 0.17, 0.16, 0.11, 0.11, 0.10, 0.08, 0.07]
ACCOUNTS = ["Savings", "Current", "Premium"]
ACC_P = [0.60, 0.25, 0.15]
CHANNELS = ["Mobile", "Branch", "Web"]
CH_P = [0.55, 0.20, 0.25]
D_MIN, D_MAX = date(2015, 1, 1), date(2026, 9, 30)

# ---------------- 1. clean base records ----------------
rows = []
for i in range(N_BASE):
    acc = rng.choice(ACCOUNTS, p=ACC_P)
    age = int(np.clip(rng.normal(38, 11), 18, 75))
    base_inc = {"Savings": 600000, "Current": 1400000, "Premium": 2600000}[acc]
    income = int(round(np.clip(rng.lognormal(np.log(base_inc), 0.45), 150000, 9000000), -3))
    ch = rng.choice(CHANNELS, p=CH_P)
    tx = int(np.clip(rng.poisson({"Mobile": 32, "Web": 22, "Branch": 9}[ch]), 0, 150))
    avg = round(float(np.clip(rng.lognormal(np.log(income / 250), 0.5), 100, 200000)), 2)
    d = D_MIN + timedelta(days=int(rng.integers(0, (D_MAX - D_MIN).days + 1)))
    rows.append({
        "customer_id": f"CUST{10001 + i}",
        "age": str(age),
        "annual_income_inr": str(income),
        "city": rng.choice(CITIES, p=CITY_P),
        "account_type": acc,
        "preferred_channel": ch,
        "signup_date": d.isoformat(),
        "transactions_last_30d": str(tx),
        "avg_transaction_amount_inr": f"{avg:.2f}",
    })
df = pd.DataFrame(rows)

# Per-column pools so one cell never carries two injected defects.
inj = []  # (issue_key, column, row_index_in_base)
def take(col, k, avoid=()):
    pool = [i for i in range(N_BASE) if i not in used[col] and i not in avoid]
    chosen = sorted(rng.choice(pool, size=k, replace=False).tolist())
    used[col].update(chosen)
    return chosen
used = {c: set() for c in df.columns}
reserved_clean = set(sorted(rng.choice(range(N_BASE), size=13, replace=False).tolist()))  # sources for dup rows
for c in used: used[c].update(reserved_clean)

def mark(key, col, idxs):
    for i in idxs: inj.append((key, col, int(i)))

# 1. missing numerical
for col, k in [("age", 18), ("annual_income_inr", 14), ("avg_transaction_amount_inr", 10)]:
    ix = take(col, k); df.loc[ix, col] = ""; mark("missing_numeric", col, ix)
# 2. missing categorical
for col, k in [("city", 9), ("preferred_channel", 12)]:
    ix = take(col, k); df.loc[ix, col] = ""; mark("missing_categorical", col, ix)
# 5. inconsistent capitalisation
ix = take("city", 16); df.loc[ix, "city"] = [c.lower() if j % 2 == 0 else c.upper() for j, c in enumerate(df.loc[ix, "city"])]; mark("case", "city", ix)
ix = take("account_type", 12); df.loc[ix, "account_type"] = [a.lower() if j % 2 == 0 else a.upper() for j, a in enumerate(df.loc[ix, "account_type"])]; mark("case", "account_type", ix)
ix = take("preferred_channel", 10); df.loc[ix, "preferred_channel"] = [c.lower() for c in df.loc[ix, "preferred_channel"]]; mark("case", "preferred_channel", ix)
# 6. leading / trailing spaces
ix = take("city", 11); df.loc[ix, "city"] = [(" " + c) if j % 2 == 0 else (c + "  ") for j, c in enumerate(df.loc[ix, "city"])]; mark("spaces", "city", ix)
ix = take("account_type", 8); df.loc[ix, "account_type"] = [a + " " for a in df.loc[ix, "account_type"]]; mark("spaces", "account_type", ix)
# 7. alternative city spellings (old official names, unambiguous)
ALT = {"Bengaluru": "Bangalore", "Mumbai": "Bombay", "Kolkata": "Calcutta", "Chennai": "Madras"}
for city, alt in ALT.items():
    pool = [i for i in range(N_BASE) if df.at[i, "city"] == city and i not in used["city"]]
    k = {"Bangalore": 7, "Bombay": 5, "Calcutta": 3, "Madras": 3}[alt]
    ix = sorted(rng.choice(pool, size=k, replace=False).tolist()); used["city"].update(ix)
    df.loc[ix, "city"] = alt; mark("alt_spelling", "city", ix)
# 15. unexpected category values
ix = take("account_type", 5); df.loc[ix, "account_type"] = ["Gold", "Gold", "Gold", "Salary", "Salary"]; mark("unexpected_category", "account_type", ix)
ix = take("preferred_channel", 5); df.loc[ix, "preferred_channel"] = ["ATM", "ATM", "ATM", "Phone", "Phone"]; mark("unexpected_category", "preferred_channel", ix)
# 9. currency symbols / thousands separators in income
def indian(n):
    s = str(n); last3, rest = s[-3:], s[:-3]
    parts = []
    while len(rest) > 2: parts.insert(0, rest[-2:]); rest = rest[:-2]
    if rest: parts.insert(0, rest)
    return ",".join(parts + [last3]) if parts else last3
ix = take("annual_income_inr", 22)
fmt = []
for j, i in enumerate(ix):
    n = int(df.at[i, "annual_income_inr"])
    fmt.append([f"₹{indian(n)}", indian(n), f"Rs. {n}"][j % 3])
df.loc[ix, "annual_income_inr"] = fmt; mark("income_format", "annual_income_inr", ix)
# 8. numbers stored as text with a unit suffix
ix = take("transactions_last_30d", 7); df.loc[ix, "transactions_last_30d"] = [f"{v} txns" for v in df.loc[ix, "transactions_last_30d"]]; mark("num_as_text", "transactions_last_30d", ix)
# 10. invalid / suspicious ages (rule: 18-100)
ix = take("age", 6); df.loc[ix, "age"] = ["250", "150", "7", "0", "-4", "999"]; mark("invalid_age", "age", ix)
# 11. negative values where not allowed
ix = take("transactions_last_30d", 4); df.loc[ix, "transactions_last_30d"] = ["-3", "-1", "-12", "-5"]; mark("negative", "transactions_last_30d", ix)
ix = take("avg_transaction_amount_inr", 3); df.loc[ix, "avg_transaction_amount_inr"] = ["-1200.00", "-450.50", "-3999.00"]; mark("negative", "avg_transaction_amount_inr", ix)
# 12. suspiciously high values (investigate, not auto-invalid)
ix = take("annual_income_inr", 3); df.loc[ix, "annual_income_inr"] = ["99000000", "250000000", "180000000"]; mark("high", "annual_income_inr", ix)
ix = take("transactions_last_30d", 3); df.loc[ix, "transactions_last_30d"] = ["950", "1200", "780"]; mark("high", "transactions_last_30d", ix)
ix = take("avg_transaction_amount_inr", 2); df.loc[ix, "avg_transaction_amount_inr"] = ["2500000.00", "4800000.00"]; mark("high", "avg_transaction_amount_inr", ix)
# 13. alternate (valid) date formats: DD/MM/YYYY with day>12 (unambiguous), DD-Mon-YYYY
pool = [i for i in range(N_BASE) if i not in used["signup_date"] and int(df.at[i, "signup_date"][8:]) > 12]
ix = sorted(rng.choice(pool, size=15, replace=False).tolist()); used["signup_date"].update(ix)
df.loc[ix, "signup_date"] = [date.fromisoformat(v).strftime("%d/%m/%Y") for v in df.loc[ix, "signup_date"]]; mark("date_ddmmyyyy", "signup_date", ix)
ix = take("signup_date", 10)
df.loc[ix, "signup_date"] = [date.fromisoformat(v).strftime("%d-%b-%Y") for v in df.loc[ix, "signup_date"]]; mark("date_ddmonyyyy", "signup_date", ix)
# 14. invalid dates
ix = take("signup_date", 6); df.loc[ix, "signup_date"] = ["2023-02-30", "2021-13-05", "31/04/2022", "2027-05-10", "unknown", "1899-12-31"]; mark("invalid_date", "signup_date", ix)

# 3. exact duplicates (8) and 4. repeated IDs with conflicting values (5), from untouched rows
src = sorted(reserved_clean)
dup_src, conf_src = src[:8], src[8:13]
extra = [df.loc[i].copy() for i in dup_src]
for i in conf_src:
    r = df.loc[i].copy()
    r["annual_income_inr"] = str(int(int(r["annual_income_inr"]) * 1.35 // 1000 * 1000))
    r["transactions_last_30d"] = str(int(r["transactions_last_30d"]) + 11)
    r["avg_transaction_amount_inr"] = f"{float(r['avg_transaction_amount_inr']) * 0.8:.2f}"
    extra.append(r)
full = pd.concat([df, pd.DataFrame(extra)], ignore_index=True)
order = rng.permutation(len(full))
full = full.iloc[order].reset_index(drop=True)
full.to_csv("06_customer_data_dirty.csv", index=False, encoding="utf-8-sig", quoting=csv.QUOTE_MINIMAL)

# ---------------- RE-DETECT every issue from the written file ----------------
raw = pd.read_csv("06_customer_data_dirty.csv", dtype=str, keep_default_na=False, encoding="utf-8-sig")
CANON_CITY = set(CITIES)
def numeric(s):
    return bool(re.fullmatch(r"-?\d+(\.\d+)?", s))
def parse_date(s):
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%d-%b-%Y"):
        try:
            return pd.to_datetime(s, format=f).date(), f
        except Exception:
            pass
    return None, None

checks = []
def add(issue_id, issue, col, mask, rule, handling):
    vals = raw.loc[mask, col].unique().tolist() if col != "(all columns)" else []
    ex = ", ".join(repr(v) for v in vals[:4])
    checks.append({"issue_id": issue_id, "issue": issue, "column": col, "rows_affected": int(mask.sum()),
                   "detection_rule": rule, "example_values": ex, "recommended_handling": handling})

st = lambda c: raw[c]
for c in ["age", "annual_income_inr", "avg_transaction_amount_inr"]:
    add("DQ01", "Missing numerical value", c, st(c) == "", "value is an empty string", "Impute median (skewed) or flag; never drop blindly")
for c in ["city", "preferred_channel"]:
    add("DQ02", "Missing categorical value", c, st(c) == "", "value is an empty string", "Fill with mode or an explicit 'Unknown' category")
exact = raw.duplicated(keep="first")
add("DQ03", "Exact duplicate row", "(all columns)", exact, "df.duplicated() is True (second copy)", "Drop the second copy")
dedup = raw[~exact]
idcount = dedup["customer_id"].value_counts()
conf_ids = idcount[idcount > 1].index
add("DQ04", "Repeated customer_id with conflicting values", "customer_id", raw["customer_id"].isin(conf_ids) & ~exact,
    "same customer_id on 2 rows that are not exact duplicates (rows counted)", "Investigate; do not delete either row without a business rule")
def case_bad(series, canon):
    s = series
    return (s != "") & (s == s.str.strip()) & (~s.isin(canon)) & (s.str.title().isin(canon))
add("DQ05", "Inconsistent capitalisation", "city", case_bad(st("city"), CANON_CITY), "trimmed value differs from a valid city only by case", ".str.strip().str.title()")
add("DQ05", "Inconsistent capitalisation", "account_type", case_bad(st("account_type"), set(ACCOUNTS)), "differs from a valid type only by case", ".str.strip().str.title()")
add("DQ05", "Inconsistent capitalisation", "preferred_channel", case_bad(st("preferred_channel"), set(CHANNELS)), "differs from a valid channel only by case", ".str.strip().str.title()")
for c in ["city", "account_type"]:
    add("DQ06", "Leading or trailing spaces", c, (st(c) != st(c).str.strip()), "value != value.strip()", ".str.strip()")
add("DQ07", "Alternative city spelling", "city", st("city").isin(ALT.values()), "value in {Bangalore, Bombay, Calcutta, Madras}", "Map to Bengaluru, Mumbai, Kolkata, Chennai")
add("DQ08", "Number stored as text (unit suffix)", "transactions_last_30d", st("transactions_last_30d").str.contains("txns"), "value ends with ' txns'", "Extract the digits, convert to int")
add("DQ09", "Currency symbol or thousands separator", "annual_income_inr", st("annual_income_inr").str.contains(r"[₹,]|Rs", regex=True), "contains ₹, Rs. or a comma", "Remove symbols and commas, convert to number")
age_num = pd.to_numeric(st("age"), errors="coerce")
add("DQ10", "Invalid age (outside 18–100)", "age", age_num.notna() & ((age_num < 18) | (age_num > 100)), "numeric and <18 or >100", "Set to missing, then impute; investigate the source")
tx_num = pd.to_numeric(st("transactions_last_30d"), errors="coerce")
avg_num = pd.to_numeric(st("avg_transaction_amount_inr"), errors="coerce")
add("DQ11", "Negative value not allowed", "transactions_last_30d", tx_num < 0, "numeric and < 0", "Set to missing; investigate")
add("DQ11", "Negative value not allowed", "avg_transaction_amount_inr", avg_num < 0, "numeric and < 0", "Set to missing; investigate")
inc_clean = pd.to_numeric(st("annual_income_inr").str.replace(r"[₹,]|Rs\.\s?", "", regex=True), errors="coerce")
add("DQ12", "Suspiciously high value", "annual_income_inr", inc_clean > 10_000_000, "> ₹1,00,00,000 (1 crore)", "Investigate before changing; cap or flag")
add("DQ12", "Suspiciously high value", "transactions_last_30d", tx_num > 300, "> 300 transactions in 30 days", "Investigate before changing; cap or flag")
add("DQ12", "Suspiciously high value", "avg_transaction_amount_inr", avg_num > 500_000, "> ₹5,00,000 average", "Investigate before changing; cap or flag")
fmts = raw["signup_date"].map(lambda s: parse_date(s)[1])
dates = raw["signup_date"].map(lambda s: parse_date(s)[0])
add("DQ13", "Date in non-standard format (DD/MM/YYYY)", "signup_date", fmts == "%d/%m/%Y", "parses as DD/MM/YYYY", "Parse with explicit formats, store as YYYY-MM-DD")
add("DQ13", "Date in non-standard format (DD-Mon-YYYY)", "signup_date", fmts == "%d-%b-%Y", "parses as DD-Mon-YYYY", "Parse with explicit formats, store as YYYY-MM-DD")
bad_date = dates.isna() | dates.map(lambda d: d is not None and not (D_MIN <= d <= D_MAX))
add("DQ14", "Invalid date", "signup_date", bad_date, "unparseable, impossible, or outside 2015-01-01 to 2026-09-30", "Set to missing (NaT); investigate")
add("DQ15", "Unexpected category value", "account_type", st("account_type").str.strip().str.title().isin(["Gold", "Salary"]) , "not Savings, Current or Premium after cleaning", "Investigate with the business; map or set to 'Unknown'")
add("DQ15", "Unexpected category value", "preferred_channel", st("preferred_channel").str.strip().str.title().isin(["Atm", "Phone"]), "not Mobile, Branch or Web after cleaning", "Investigate with the business; map or set to 'Unknown'")

man = pd.DataFrame(checks)

# ---------------- verify detection == injection ----------------
inj_counts = {}
for key, col, _ in inj:
    inj_counts[(key, col)] = inj_counts.get((key, col), 0) + 1
expect = {("DQ01", c): inj_counts[("missing_numeric", c)] for c in ["age", "annual_income_inr", "avg_transaction_amount_inr"]}
expect.update({("DQ02", c): inj_counts[("missing_categorical", c)] for c in ["city", "preferred_channel"]})
expect[("DQ03", "(all columns)")] = 8
expect[("DQ04", "customer_id")] = 10
expect.update({("DQ05", c): inj_counts[("case", c)] for c in ["city", "account_type", "preferred_channel"]})
expect.update({("DQ06", c): inj_counts[("spaces", c)] for c in ["city", "account_type"]})
expect[("DQ07", "city")] = inj_counts[("alt_spelling", "city")]
expect[("DQ08", "transactions_last_30d")] = inj_counts[("num_as_text", "transactions_last_30d")]
expect[("DQ09", "annual_income_inr")] = inj_counts[("income_format", "annual_income_inr")]
expect[("DQ10", "age")] = inj_counts[("invalid_age", "age")]
expect.update({("DQ11", c): inj_counts[("negative", c)] for c in ["transactions_last_30d", "avg_transaction_amount_inr"]})
expect.update({("DQ12", c): inj_counts[("high", c)] for c in ["annual_income_inr", "transactions_last_30d", "avg_transaction_amount_inr"]})
expect[("DQ14", "signup_date")] = inj_counts[("invalid_date", "signup_date")]
expect.update({("DQ15", c): inj_counts[("unexpected_category", c)] for c in ["account_type", "preferred_channel"]})
fmt_rows = man[man.issue_id == "DQ13"].rows_affected.tolist()
assert fmt_rows == [15, 10], fmt_rows
for _, r in man.iterrows():
    k = (r.issue_id, r.column)
    if k in expect:
        assert r.rows_affected == expect[k], (k, r.rows_affected, expect[k])
man.insert(0, "seed", SEED)
man.to_csv("Trainer_Data_Quality_Manifest.csv", index=False, encoding="utf-8-sig")
print("rows in CSV:", len(raw), "| base customers:", N_BASE)
print(man[["issue_id", "column", "rows_affected"]].to_string(index=False))
print("ALL COUNTS VERIFIED")
